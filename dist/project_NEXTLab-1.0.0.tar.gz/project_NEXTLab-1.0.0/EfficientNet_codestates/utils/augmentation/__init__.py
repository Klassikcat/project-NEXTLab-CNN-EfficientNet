from EfficientNet_codestates.utils import augmentation
from EfficientNet_codestates.utils.augmentation import (
    augmentation as Augmentation,
    launcher_augument,
    launcher_classname
)