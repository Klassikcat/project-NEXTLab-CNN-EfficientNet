from setuptools import setup, find_packages

setup(
    name='project_NEXTLab',
    version='1.0.0',
    packages=find_packages(exclude=['image']),
    url='https://github.com/Klassikcat',
    license='',
    author='shinjeongtae',
    author_email='shinjeongtae@gmail.com',
    description='Codestates NETXLab EfficientNet'
)
